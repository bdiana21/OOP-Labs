public class PremiumNotEnabledException extends Exception{
    public PremiumNotEnabledException(String message) {
        super(message);
    }
}
